@echo off
cd /d "%~dp0"
if not exist node_modules (
  echo Instalowanie zaleznosci...
  npm install
)
if not exist .env (
  echo.
  echo BRAK PLIKU .env
  echo Skopiuj .env.example jako .env i wpisz klucz API Warszawy.
  pause
  exit /b
)
npm start
pause
