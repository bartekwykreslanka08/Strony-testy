const state = {
  routes: {},
  dictionary: {},
  selectedLine: null,
  selectedVariant: null,
  variants: [],
  currentType: "all"
};

const $ = selector => document.querySelector(selector);

const lineGrid = $("#lineGrid");
const lineSearch = $("#lineSearch");
const transportFilter = $("#transportFilter");
const modal = $("#routeModal");

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function lineType(line) {
  const value = String(line).toUpperCase();

  if (/^M[12]$/.test(value)) return "metro";
  if (/^[0-9]+$/.test(value)) {
    const n = Number(value);
    // Numery 1–39 są używane m.in. przez tramwaje, ale w API
    // ostatecznie typ najlepiej ustalać na podstawie dostępności
    // w danych tras. W UI rozróżniamy je heurystycznie.
    if (n >= 1 && n <= 39) return "tram";
    return "bus";
  }

  if (/^(S|R|KM|WKD)/i.test(value)) return "other";
  return "other";
}

function typeLabel(type) {
  return ({
    bus: "autobus",
    tram: "tramwaj",
    metro: "metro",
    other: "pozostałe"
  })[type] || "linia";
}

function updateClock() {
  const now = new Date();
  const text = now.toLocaleTimeString("pl-PL", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });

  $("#clock").textContent = text;
  $("#screenClock").textContent = text.slice(0, 5);
}

setInterval(updateClock, 1000);
updateClock();

async function loadData() {
  $("#apiStatus").textContent = "Pobieranie tras...";
  lineGrid.innerHTML = `<div class="loading">Pobieranie prawdziwych danych Warszawy...</div>`;

  try {
    const response = await fetch("/api/routes");
    const data = await response.json();

    if (!response.ok) throw new Error(data.error || "Nie udało się pobrać tras.");

    state.routes = data.routes || {};
    state.dictionary = data.dictionary || {};

    $("#apiStatus").textContent =
      `API OK • ${Object.keys(state.routes).length} linii w danych`;

    renderLines();
  } catch (error) {
    $("#apiStatus").textContent = "Błąd połączenia z API";
    lineGrid.innerHTML = `<div class="error">${escapeHtml(error.message)}<br><br>
      Sprawdź plik <b>.env</b> i klucz WARSZAWA_API_KEY.
    </div>`;
  }
}

function renderLines() {
  const query = lineSearch.value.trim().toUpperCase();
  const filter = transportFilter.value;

  const lines = Object.keys(state.routes)
    .filter(line => line.toUpperCase().includes(query))
    .filter(line => filter === "all" || lineType(line) === filter)
    .sort((a, b) => {
      const an = Number(a);
      const bn = Number(b);
      if (!Number.isNaN(an) && !Number.isNaN(bn)) return an - bn;
      return a.localeCompare(b, "pl");
    });

  $("#lineCount").textContent = lines.length;

  if (!lines.length) {
    lineGrid.innerHTML = `<div class="error">Nie znaleziono linii.</div>`;
    return;
  }

  lineGrid.innerHTML = lines.map(line => {
    const type = lineType(line);
    return `
      <button class="line-card" data-line="${escapeHtml(line)}">
        <span class="line-number">${escapeHtml(line)}</span>
        <span class="line-type">${typeLabel(type)}</span>
      </button>
    `;
  }).join("");

  document.querySelectorAll(".line-card").forEach(button => {
    button.addEventListener("click", () => openLine(button.dataset.line));
  });
}

function getVariants(line) {
  return Object.entries(state.routes[line] || {})
    .map(([id, stops]) => ({ id, stops }))
    .filter(v => v.stops.length > 0);
}

function getDestination(stops) {
  if (!stops?.length) return "Brak danych";
  return stops[stops.length - 1].name;
}

function openLine(line) {
  state.selectedLine = line;
  state.variants = getVariants(line);
  state.selectedVariant = state.variants[0]?.id || null;

  $("#modalLine").textContent = line;
  $("#screenLine").textContent = line;

  renderDirectionTabs();
  renderSelectedVariant();

  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function renderDirectionTabs() {
  const tabs = $("#directionTabs");

  tabs.innerHTML = state.variants.map((variant, index) => `
    <button class="direction-tab ${variant.id === state.selectedVariant ? "active" : ""}"
      data-variant="${escapeHtml(variant.id)}">
      KIERUNEK ${index + 1}: ${escapeHtml(getDestination(variant.stops))}
    </button>
  `).join("");

  tabs.querySelectorAll(".direction-tab").forEach(button => {
    button.addEventListener("click", () => {
      state.selectedVariant = button.dataset.variant;
      renderDirectionTabs();
      renderSelectedVariant();
    });
  });
}

function renderSelectedVariant() {
  const variant = state.variants.find(v => v.id === state.selectedVariant);

  if (!variant) {
    $("#routeStops").innerHTML = `<div class="error">Brak danych trasy.</div>`;
    return;
  }

  const destination = getDestination(variant.stops);
  $("#modalTitle").textContent = destination;
  $("#screenDestination").textContent = destination;

  $("#routeStops").innerHTML = variant.stops.map((stop, index) => `
    <div class="stop ${index === 0 ? "first" : ""} ${index === variant.stops.length - 1 ? "last" : ""}">
      <div class="stop-name">${escapeHtml(stop.name)}</div>
      <div class="stop-meta">
        ${escapeHtml(stop.stopGroupId)}/${escapeHtml(stop.stopNumber)}
        ${stop.street ? " • " + escapeHtml(stop.street) : ""}
        ${stop.type ? " • " + escapeHtml(stop.type) : ""}
      </div>
    </div>
  `).join("");

  $("#vehiclePanel").classList.add("hidden");
  $("#vehicleList").innerHTML = "";
}

async function loadLiveVehicles() {
  const line = state.selectedLine;
  const type = lineType(line);
  const apiType = type === "tram" ? 2 : 1;

  $("#vehiclePanel").classList.remove("hidden");
  $("#vehicleList").innerHTML = `<div class="loading">Pobieranie pozycji pojazdów...</div>`;

  try {
    const response = await fetch(`/api/vehicles/line/${encodeURIComponent(line)}?type=${apiType}`);
    const data = await response.json();

    if (!response.ok) throw new Error(data.error || "Błąd danych realtime.");

    if (!data.length) {
      $("#vehicleList").innerHTML =
        `<div class="loading">Brak aktualnie raportowanych pojazdów tej linii.</div>`;
      return;
    }

    $("#vehicleList").innerHTML = data.map(vehicle => `
      <div class="vehicle-row">
        <div><span class="muted">POJAZD</span><br><strong>${escapeHtml(vehicle.VehicleNumber)}</strong></div>
        <div><span class="muted">BRYGADA</span><br>${escapeHtml(vehicle.Brigade)}</div>
        <div><span class="muted">CZAS</span><br>${escapeHtml(vehicle.Time)}</div>
      </div>
    `).join("");
  } catch (error) {
    $("#vehicleList").innerHTML =
      `<div class="error">${escapeHtml(error.message)}</div>`;
  }
}

lineSearch.addEventListener("input", renderLines);
transportFilter.addEventListener("change", renderLines);

$("#liveVehiclesBtn").addEventListener("click", loadLiveVehicles);

$("#refreshBtn").addEventListener("click", loadData);

$("#fullscreenBtn").addEventListener("click", async () => {
  try {
    if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
    else await document.exitFullscreen();
  } catch {}
});

document.querySelectorAll("[data-close]").forEach(element => {
  element.addEventListener("click", closeModal);
});

function closeModal() {
  modal.classList.add("hidden");
  document.body.style.overflow = "";
}

document.addEventListener("keydown", event => {
  if (event.key === "Escape") closeModal();
});

loadData();