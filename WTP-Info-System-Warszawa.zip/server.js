import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.WARSZAWA_API_KEY;

const ZTM = "https://api.um.warszawa.pl/api/action";
const RESOURCE_ID = "f2e5503e-927d-4ad3-9500-4ab9e55deb59";

const cache = new Map();
const CACHE_TTL = {
  reference: 24 * 60 * 60 * 1000,
  vehicles: 15 * 1000
};

function requireKey(res) {
  if (!API_KEY) {
    res.status(500).json({
      error: "Brak WARSZAWA_API_KEY. Skopiuj .env.example jako .env i wpisz swój klucz API."
    });
    return false;
  }
  return true;
}

async function ztm(pathname, params = {}) {
  const url = new URL(`${ZTM}/${pathname}`);
  url.searchParams.set("apikey", API_KEY);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, String(value));
    }
  }

  const response = await fetch(url);
  const data = await response.json();

  // API miasta potrafi zwrócić HTTP 200 z błędem w polu result.
  if (typeof data?.result === "string" && data.result !== "true") {
    const error = data.error || data.result;
    throw new Error(error);
  }

  return data.result;
}

async function cached(key, ttl, fn) {
  const now = Date.now();
  const hit = cache.get(key);
  if (hit && now - hit.time < ttl) return hit.value;

  const value = await fn();
  cache.set(key, { time: now, value });
  return value;
}

function normalizeRows(result) {
  if (!Array.isArray(result)) return [];
  return result.map(row => {
    const obj = {};
    for (const item of row?.values || []) {
      obj[item.key] = item.value;
    }
    return obj;
  });
}

function makeRouteLine(result, dictionary) {
  const streets = dictionary?.ulice || {};
  const stopNames = dictionary?.zespoly_przystankowe || {};
  const stopTypes = dictionary?.typy_przystankow || {};

  const output = {};

  for (const [line, variants] of Object.entries(result || {})) {
    output[line] = {};

    for (const [variantId, stopsObj] of Object.entries(variants || {})) {
      const ordered = Object.entries(stopsObj || {})
        .sort((a, b) => Number(a[0]) - Number(b[0]))
        .map(([order, stop]) => ({
          order: Number(order),
          stopGroupId: String(stop.nr_zespolu),
          stopNumber: String(stop.nr_przystanku).padStart(2, "0"),
          name: stopNames[String(stop.nr_zespolu)] || `Przystanek ${stop.nr_zespolu}`,
          street: streets[String(stop.ulica_id)] || "",
          type: stopTypes[String(stop.typ)] || "",
          distance: Number(stop.odleglosc || 0)
        }));

      output[line][variantId] = ordered;
    }
  }

  return output;
}

app.get("/api/status", (req, res) => {
  res.json({
    ok: Boolean(API_KEY),
    service: "Warszawa WTP Info System",
    apiKeyConfigured: Boolean(API_KEY),
    time: new Date().toISOString()
  });
});

app.get("/api/routes", async (req, res) => {
  if (!requireKey(res)) return;

  try {
    const payload = await cached("routes+dictionary", CACHE_TTL.reference, async () => {
      const [routes, dictionary] = await Promise.all([
        ztm("public_transport_routes"),
        ztm("public_transport_dictionary")
      ]);

      return {
        routes: makeRouteLine(routes, dictionary),
        dictionary
      };
    });

    res.json(payload);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

app.get("/api/dictionary", async (req, res) => {
  if (!requireKey(res)) return;

  try {
    const dictionary = await cached(
      "dictionary",
      CACHE_TTL.reference,
      () => ztm("public_transport_dictionary")
    );
    res.json(dictionary);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

app.get("/api/vehicles", async (req, res) => {
  if (!requireKey(res)) return;

  const type = req.query.type === "2" ? 2 : 1;

  try {
    const rows = await cached(
      `vehicles-${type}`,
      CACHE_TTL.vehicles,
      () => ztm("busestrams_get", { resource_id: RESOURCE_ID, type })
    );

    const now = Date.now();
    const fresh = (Array.isArray(rows) ? rows : []).filter(vehicle => {
      const t = Date.parse(String(vehicle.Time).replace(" ", "T"));
      return Number.isNaN(t) || now - t < 120000;
    });

    res.json(fresh);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

app.get("/api/vehicles/line/:line", async (req, res) => {
  if (!requireKey(res)) return;

  const line = String(req.params.line).trim().toUpperCase();
  const type = req.query.type === "2" ? 2 : 1;

  try {
    const rows = await cached(
      `vehicles-${type}`,
      CACHE_TTL.vehicles,
      () => ztm("busestrams_get", { resource_id: RESOURCE_ID, type })
    );

    const filtered = (Array.isArray(rows) ? rows : []).filter(
      v => String(v.Lines || "").trim().toUpperCase() === line
    );

    res.json(filtered);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

app.get("/api/lines-at-stop", async (req, res) => {
  if (!requireKey(res)) return;

  const { stopId, stopNr } = req.query;
  if (!stopId || !stopNr) {
    return res.status(400).json({ error: "Podaj stopId i stopNr." });
  }

  try {
    const result = await ztm("dbtimetable_get", {
      id: "88cd555f-6f31-43ca-9de4-66c479ad5942",
      busstopId: stopId,
      busstopNr: stopNr
    });

    res.json(normalizeRows(result));
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

app.get("/api/departures", async (req, res) => {
  if (!requireKey(res)) return;

  const { stopId, stopNr, line } = req.query;
  if (!stopId || !stopNr || !line) {
    return res.status(400).json({
      error: "Podaj stopId, stopNr i line."
    });
  }

  try {
    const result = await ztm("dbtimetable_get", {
      id: "e923fa0e-d96c-43f9-ae6e-60518c9f3238",
      busstopId: stopId,
      busstopNr: stopNr,
      line
    });

    res.json(normalizeRows(result));
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

app.use(express.static(path.join(__dirname, "public")));

app.get("*splat", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`WTP Info System działa na http://localhost:${PORT}`);
  if (!API_KEY) {
    console.warn("UWAGA: brak WARSZAWA_API_KEY w pliku .env");
  }
});