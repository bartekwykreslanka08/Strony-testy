#!/bin/sh
cd "$(dirname "$0")"
if [ ! -d node_modules ]; then npm install; fi
if [ ! -f .env ]; then
  echo "Brak .env — skopiuj .env.example i wpisz klucz API."
  exit 1
fi
npm start
