# WTP Info System — Warszawa

Własna strona WWW imitująca ideę elektronicznego systemu informacji pasażerskiej, ale zbudowana od zera.

## Co już działa

- prawdziwe dane tras z API miasta Warszawy,
- słownik nazw przystanków i ulic,
- lista linii pobierana automatycznie,
- wyszukiwarka linii,
- filtrowanie typów linii,
- schemat trasy z prawdziwą kolejnością przystanków,
- wybór wariantu/kierunku,
- tryb pełnoekranowy,
- zegar,
- pozycje autobusów/tramwajów z API realtime,
- odświeżanie danych,
- backend chroniący klucz API przed umieszczeniem go w publicznym HTML.

## Ważne

Do działania potrzebujesz darmowego klucza API miasta Warszawy.

Oficjalna platforma:
https://api.um.warszawa.pl/

API wykorzystuje m.in.:
- `public_transport_routes` — topologia tras,
- `public_transport_dictionary` — nazwy przystanków/ulic,
- `busestrams_get` — pozycje autobusów i tramwajów,
- `dbtimetable_get` — linie na słupku i rozkłady.

## Uruchomienie Windows

1. Zainstaluj Node.js LTS.
2. Otwórz folder projektu w terminalu.
3. Wykonaj:

```bash
npm install
```

4. Skopiuj `.env.example` do `.env`.
5. Otwórz `.env` i wpisz swój klucz:

```text
WARSZAWA_API_KEY=TWÓJ_KLUCZ
```

6. Uruchom:

```bash
npm start
```

7. Otwórz:

http://localhost:3000

## Uruchomienie telefonu

Telefon nie musi mieć Node.js. Najwygodniej uruchomić backend na komputerze/serwerze.

Jeżeli chcesz mieć stronę publicznie, możesz później wrzucić backend np. na Render, Railway, VPS lub inny hosting Node.js.

## Dlaczego nie wkładamy klucza bezpośrednio do index.html?

Bo każdy odwiedzający mógłby go zobaczyć. Klucz jest w `.env`, a przeglądarka rozmawia tylko z naszym backendem.

## Rozszerzenia na kolejną wersję

1. mapa Warszawy,
2. wyszukiwarka przystanków,
3. odjazdy z konkretnego słupka,
4. tablica odjazdów jak na przystanku,
5. animacja "następny przystanek",
6. pozycja pojazdu na mapie,
7. filtrowanie po dzielnicach,
8. ulubione linie/przystanki,
9. PWA na telefon,
10. automatyczne pobieranie/cachowanie GTFS,
11. metro/SKM/WKD/KM,
12. tryb "ekran w autobusie" z automatycznym przewijaniem.

## Źródło danych

Dane transportowe pochodzą z API miasta Warszawy. API wymaga klucza.

Projekt nie jest oficjalną aplikacją WTP/ZTM i nie powinien sugerować, że jest oficjalnym systemem miejskim.