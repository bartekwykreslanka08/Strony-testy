# WTP — wersja dla GitHub Pages + Cloudflare Worker

To jest wersja przygotowana dla osoby, która ma tylko telefon i edytuje projekt przez GitHub.

## CZĘŚĆ A — GitHub Pages

Do repozytorium GitHub wrzuć **tylko zawartość folderu `github-pages`**:

- index.html
- style.css
- app.js

W GitHub:
Settings → Pages → Deploy from a branch → wybierz `main` i folder `/ (root)` → Save.

## CZĘŚĆ B — Cloudflare Worker

GitHub Pages nie powinien przechowywać sekretu API. Dlatego backend/proxy jest w Cloudflare Worker.

1. Załóż konto Cloudflare.
2. Wejdź w Workers & Pages.
3. Utwórz nowego Workera.
4. W edytorze wklej zawartość `cloudflare-worker/worker.js`.
5. W ustawieniach Workera dodaj Secret:
   - Name: `WARSZAWA_API_KEY`
   - Value: Twój klucz API miasta Warszawy.
6. Wdróż Worker.
7. Skopiuj jego adres, np. `https://wtp-api-xxxx.workers.dev`.

## CZĘŚĆ C — połącz GitHub z Workerem

Otwórz `index.html` na GitHubie i znajdź:

const API_BASE = "WKLEJ_TUTAJ_ADRES_WORKERA";

Zmień na:

const API_BASE = "https://wtp-api-xxxx.workers.dev";

Zapisz plik.

Po kilku minutach GitHub Pages powinien korzystać z danych.

## Dane

Projekt używa miejskiego API Warszawy:
- public_transport_routes
- public_transport_dictionary
- busestrams_get

Klucz API trzymaj wyłącznie jako Secret w Workerze.

## Uwaga

Projekt jest nieoficjalnym projektem fanowskim/inżynierskim i nie należy przedstawiać go jako oficjalnej strony WTP/ZTM.

## Następny etap

Można dodać:
- wyszukiwarkę przystanków,
- rozkłady jazdy,
- tablicę odjazdów,
- mapę,
- animację następnego przystanku,
- ulubione,
- PWA,
- dane GTFS,
- bardziej wierne odwzorowanie ekranu z filmu.
