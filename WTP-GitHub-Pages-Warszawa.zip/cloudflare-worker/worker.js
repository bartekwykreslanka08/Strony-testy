/*
  CLOUDFLARE WORKER — backend/proxy dla GitHub Pages.
  1. W Cloudflare utwórz Worker.
  2. Wklej ten kod.
  3. Settings -> Variables and Secrets -> dodaj sekret:
       WARSZAWA_API_KEY = Twój klucz API miasta Warszawy
  4. Zapisz i wdroż.
*/

const API = "https://api.um.warszawa.pl/api/action";
const RESOURCE_ID = "f2e5503e-927d-4ad3-9500-4ab9e55deb59";

const cors = {
  "Access-Control-Allow-Origin":"*",
  "Access-Control-Allow-Methods":"GET,OPTIONS",
  "Access-Control-Allow-Headers":"Content-Type"
};

const json = (data,status=200)=>new Response(JSON.stringify(data),{
  status,headers:{"Content-Type":"application/json; charset=utf-8",...cors}
});

async function api(env,path,params={}){
  if(!env.WARSZAWA_API_KEY)throw Error("Brak sekretu WARSZAWA_API_KEY w Cloudflare Worker.");
  const u=new URL(`${API}/${path}`);
  u.searchParams.set("apikey",env.WARSZAWA_API_KEY);
  for(const [k,v] of Object.entries(params))if(v!==undefined&&v!==null&&v!=="")u.searchParams.set(k,v);
  const r=await fetch(u);
  const d=await r.json();
  if(typeof d?.result==="string"&&d.result!=="true")throw Error(d.error||d.result);
  return d.result;
}

function rows(result){
  if(!Array.isArray(result))return [];
  return result.map(row=>Object.fromEntries((row.values||[]).map(x=>[x.key,x.value])));
}

function routeData(raw,dict){
  const names=dict?.zespoly_przystankowe||{}, streets=dict?.ulice||{}, types=dict?.typy_przystankow||{};
  const out={};
  for(const [line,variants] of Object.entries(raw||{})){
    out[line]={};
    for(const [variant,stops] of Object.entries(variants||{})){
      out[line][variant]=Object.entries(stops||{}).sort((a,b)=>+a[0]-+b[0]).map(([order,s])=>({
        order:+order,stopGroupId:String(s.nr_zespolu),stopNumber:String(s.nr_przystanku).padStart(2,"0"),
        name:names[String(s.nr_zespolu)]||`Przystanek ${s.nr_zespolu}`,
        street:streets[String(s.ulica_id)]||"",type:types[String(s.typ)]||"",distance:+(s.odleglosc||0)
      }));
    }
  }
  return out;
}

export default {
  async fetch(request,env){
    if(request.method==="OPTIONS")return new Response(null,{headers:cors});
    const url=new URL(request.url);
    try{
      if(url.pathname==="/routes"){
        const [raw,dict]=await Promise.all([api(env,"public_transport_routes"),api(env,"public_transport_dictionary")]);
        return json({routes:routeData(raw,dict)});
      }
      if(url.pathname.startsWith("/vehicles/line/")){
        const line=decodeURIComponent(url.pathname.split("/").pop()).toUpperCase();
        const type=url.searchParams.get("type")==="2"?2:1;
        const data=await api(env,"busestrams_get",{resource_id:RESOURCE_ID,type});
        return json((Array.isArray(data)?data:[]).filter(v=>String(v.Lines||"").trim().toUpperCase()===line));
      }
      if(url.pathname==="/vehicles"){
        const type=url.searchParams.get("type")==="2"?2:1;
        return json(await api(env,"busestrams_get",{resource_id:RESOURCE_ID,type}));
      }
      if(url.pathname==="/dictionary"){
        return json(await api(env,"public_transport_dictionary"));
      }
      return json({ok:true,name:"WTP API proxy",routes:"/routes",vehicles:"/vehicles",line:"/vehicles/line/{LINIA}"});
    }catch(e){
      return json({error:e.message||"Błąd"},502);
    }
  }
};