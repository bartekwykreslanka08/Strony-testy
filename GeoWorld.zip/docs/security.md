# Security

The server is authoritative for game state, locations, scoring and round expiry. Validate all request bodies, use parameterized SQL, enforce ownership and roles, apply CORS and rate limits, reject duplicate round submissions, and audit suspicious timing or request patterns.

Production authentication requires secure cookies, CSRF strategy appropriate to the client architecture, session rotation and memory-hard password hashing. Secrets never belong in source control or browser bundles.
