# Database

D1 schema covers users, profiles, maps, locations, games, rounds, guesses, scores, leaderboards, daily challenges, achievements, multiplayer, reports and sessions. Indexes target country filtering, chronological game access, scoreboards, daily rankings, rooms and moderation queues.

For very large datasets, use stable random keys/buckets or precomputed location partitions rather than `ORDER BY RANDOM()`.
