# Legal checklist

Terms and Privacy pages are application routes but production legal copy must be reviewed for the operator's jurisdiction, GDPR/UK GDPR applicability, cookies/consent, user-generated content, moderation, data retention, deletion rights, minors and provider attribution/licensing.
