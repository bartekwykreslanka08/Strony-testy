# API

Core routes include health, maps, games, rounds, guesses, players, leaderboard, daily challenge and multiplayer room endpoints. Guess scoring is calculated server-side.

Authentication endpoints should be added behind the session service before public launch; password hashes must use a memory-hard password hashing implementation and sessions must be stored as hashes.
