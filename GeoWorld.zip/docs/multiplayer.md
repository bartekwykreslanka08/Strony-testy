# Multiplayer

Durable Objects are the intended authoritative coordinator for room membership, ready state, countdown, round state and score synchronization. Target room sizes are 2–10 players. Competitive rating changes should be calculated server-side after a completed match.
