# Game modes

Classic, No Move, NMPZ, Time Attack, Country Streak and Competitive are represented in the shared domain model. The scoring engine is isolated so mode-specific formulas can evolve independently.
