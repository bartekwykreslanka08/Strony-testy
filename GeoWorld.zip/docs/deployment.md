# Deployment

## Frontend

Build `apps/web` and publish the generated `dist` directory to GitHub Pages. Configure the API base URL and map style through the build environment.

## Worker

Create a D1 database named `geoworld`, apply migrations, configure Durable Objects, then deploy `apps/api` with Wrangler. Store provider API keys and application secrets as Worker secrets.

## Imagery

Select a licensed Street View/imagery provider. Review current provider terms, attribution requirements, caching/storage restrictions and API pricing before enabling production imagery. Do not proxy or persist provider imagery in R2 unless the provider expressly permits it.
