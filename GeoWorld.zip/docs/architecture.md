# Architecture

GeoWorld uses a Vite React SPA with React Router, TanStack Query, Zustand, MapLibre GL JS and Framer Motion. The API is a Hono application on Cloudflare Workers. D1 is the durable relational store and Durable Objects own authoritative multiplayer room state.

The frontend treats provider imagery as an abstraction. Production API secrets stay in Worker bindings. The game engine and scoring engine run server-side; the browser only submits a guess and timing telemetry.
