# Data import

`scripts/import-locations.mjs` validates CSV or JSON coordinate datasets. For million-scale imports, batch into D1-friendly chunks, precompute stable selection buckets, and monitor Worker CPU/subrequest limits.
