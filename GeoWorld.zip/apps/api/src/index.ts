import {Hono} from 'hono'; import {cors} from 'hono/cors'; import {GameEngine} from './engine/game'; import {scoreGuess} from './engine/scoring'; import {DemoImageryProvider} from './providers/imagery';
export interface Env{DB:D1Database;GAME_ROOMS:DurableObjectNamespace;GOOGLE_MAPS_API_KEY?:string;SESSION_SECRET?:string;DAILY_CHALLENGE_SECRET?:string;ENVIRONMENT:string}
const app=new Hono<{Bindings:Env}>(); app.use('*',cors({origin:'*',allowHeaders:['Content-Type','Authorization'],allowMethods:['GET','POST','PUT','DELETE','OPTIONS']})); const game=new GameEngine(); const imagery=new DemoImageryProvider();
app.get('/health',(c)=>c.json({ok:true,service:'geoworld-api',environment:c.env.ENVIRONMENT||'local',timestamp:new Date().toISOString()}));
app.get('/api/maps',(c)=>c.json({items:[{id:'world',name:'World Explorer',description:'A balanced global starter map',locations:1000000},{id:'europe',name:'Europe Focus',description:'Cities, countryside and coastlines',locations:120000}]}));
app.get('/api/maps/:id',(c)=>c.json({id:c.req.param('id'),name:'World Explorer',description:'Demo map metadata',locations:1000000}));
app.post('/api/games',(c)=>c.json(game.createGame('classic'),201));
app.get('/api/games/:id',(c)=>c.json({id:c.req.param('id'),status:'active',round:1,totalRounds:5}));
app.post('/api/games/:id/rounds',(c)=>c.json({round:game.createRound({id:'demo',lat:51.9194,lng:19.1451,countryCode:'PL',countryName:'Poland'})}),201);
app.post('/api/rounds/:id/guess',async(c)=>{const body=await c.req.json<{lat:number;lng:number;timeSeconds:number;actualLat?:number;actualLng?:number}>(); const actual={lat:body.actualLat??51.9194,lng:body.actualLng??19.1451}; return c.json({roundId:c.req.param('id'),result:scoreGuess(actual,{lat:body.lat,lng:body.lng},body.timeSeconds,'classic')})});
app.get('/api/player/:id',(c)=>c.json({id:c.req.param('id'),username:'Explorer',level:12,xp:4280,games:86,wins:31,averageScore:4120,bestScore:5000,streak:7,totalDistance:18240,favoriteCountries:['Poland','Japan','Norway']}));
app.get('/api/leaderboard',(c)=>c.json({items:[{rank:1,username:'Atlas',rating:1832,score:4981},{rank:2,username:'Meridian',rating:1798,score:4910},{rank:3,username:'Explorer',rating:1724,score:4788}]}));
app.get('/api/daily',(c)=>c.json({date:new Date().toISOString().slice(0,10),status:'open',leaderboard:[]})); app.post('/api/daily/submit',(c)=>c.json({accepted:true})); app.post('/api/multiplayer/rooms',(c)=>c.json({id:crypto.randomUUID(),status:'lobby',players:[]}),201); app.get('/api/multiplayer/rooms/:id',(c)=>c.json({id:c.req.param('id'),status:'lobby',players:[]}));
app.get('/api/imagery/:id',async(c)=>c.json(await imagery.getPanorama(c.req.param('id'))));
export class GameRoom{state:DurableObjectState; constructor(state:DurableObjectState){this.state=state} async fetch(request:Request){return new Response(JSON.stringify({ok:true,room:'durable-object'}),{headers:{'content-type':'application/json'}})}}
export default app;
