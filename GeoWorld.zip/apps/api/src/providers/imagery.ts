export interface ImageProvider{getPanorama(locationId:string):Promise<{provider:string,assetUrl:string}|null>}
export interface LocationProvider{findCoverage(lat:number,lng:number):Promise<{lat:number,lng:number,provider:string}|null>}
export class DemoImageryProvider implements ImageProvider,LocationProvider{async getPanorama(locationId:string){return {provider:'demo',assetUrl:`/demo/panorama/${encodeURIComponent(locationId)}`}} async findCoverage(lat:number,lng:number){return {lat,lng,provider:'demo'}}}
