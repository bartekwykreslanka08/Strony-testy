import {create} from 'zustand'; import type {LatLng,GameMode} from '@geoworld/shared';
interface State {mode:GameMode; round:number; score:number; guess:LatLng|null; setGuess:(guess:LatLng|null)=>void; setMode:(mode:GameMode)=>void; next:()=>void;}
export const useGameStore=create<State>((set)=>({mode:'classic',round:1,score:0,guess:null,setGuess:(guess)=>set({guess}),setMode:(mode)=>set({mode}),next:()=>set(s=>({round:s.round+1,guess:null}))}));
