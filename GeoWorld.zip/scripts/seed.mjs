console.log('GeoWorld development seed: use Wrangler D1 migrations followed by database/seed.sql.');
