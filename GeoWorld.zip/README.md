# GeoWorld

GeoWorld is a full-stack geography game platform designed around React, TypeScript, MapLibre, Cloudflare Workers, D1 and Durable Objects.

## Repository

- `apps/web` — responsive Vite frontend
- `apps/api` — Hono API and game services
- `packages/shared` — shared domain types and geo/scoring utilities
- `database` — D1 migrations and seed data
- `scripts` — dataset tooling
- `docs` — architecture and operational documentation

## Local development

1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and `.dev.vars.example` to `.dev.vars`.
3. Run `npm install`.
4. Run `npm run dev -w apps/api` and `npm run dev -w apps/web` in separate terminals.
5. Run `npm run lint`, `npm run typecheck`, `npm test`, and `npm run build`.

The demo imagery provider is intentionally self-contained. Production imagery requires a provider account and compliance review; provider secrets belong in Cloudflare Worker secrets, never in the browser bundle.

## Production

The frontend is prepared for GitHub Pages and the API for Cloudflare Workers. See `docs/deployment.md` for environment, D1, Durable Objects and provider configuration.

## Legal note

Provider terms, attribution, privacy language, retention periods and jurisdiction-specific requirements must be reviewed by the operator's legal counsel before production launch.
