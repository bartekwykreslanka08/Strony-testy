import {describe,it,expect} from 'vitest'; import {haversineKm,calculateScore} from './index';
describe('geo',()=>{it('calculates zero distance',()=>expect(haversineKm({lat:0,lng:0},{lat:0,lng:0})).toBe(0)); it('scores closer guesses higher',()=>expect(calculateScore(10,10,'classic').score).toBeGreaterThan(calculateScore(1000,10,'classic').score));});
