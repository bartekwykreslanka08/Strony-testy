export type GameMode = 'classic'|'no-move'|'nmpz'|'time-attack'|'country-streak'|'competitive';
export type LatLng = {lat:number; lng:number};
export type Guess = LatLng & {submittedAt:number};
export type RoundState = 'pending'|'active'|'guessed'|'expired'|'complete';
export type UserRole = 'user'|'moderator'|'admin'|'superadmin';
export interface Location {id:string; lat:number; lng:number; countryCode:string; countryName:string; region?:string; city?:string; heading?:number;}
export interface ScoreResult {score:number; distanceKm:number; timeBonus:number; mode:GameMode;}
export function haversineKm(a:LatLng,b:LatLng):number {const R=6371; const p=Math.PI/180; const dLat=(b.lat-a.lat)*p; const dLon=(b.lng-a.lng)*p; const x=Math.sin(dLat/2)**2+Math.cos(a.lat*p)*Math.cos(b.lat*p)*Math.sin(dLon/2)**2; return 2*R*Math.asin(Math.sqrt(x));}
export function calculateScore(distanceKm:number,timeSeconds:number,mode:GameMode):ScoreResult {const capped=Math.min(Math.max(distanceKm,0),20000); const base=5000*Math.exp(-capped/1200); const timeBonus=mode==='time-attack'?Math.max(0,Math.min(500,500-timeSeconds*5)):0; return {score:Math.round(Math.max(0,Math.min(5000,base+timeBonus))),distanceKm:capped,timeBonus,mode};}
